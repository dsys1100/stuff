There are alternative versions of assets in this theme. "ALT" is included in their name to distinguish them. Rename them so that they do not have "ALT" in their name and overwrite the original file to use them.

Currently the available alternatives are:

tasks.svgz

Found in: 

widgets/

Switching to the ALT will give you 32px icons on the task manager instead of 22px.
